document.getElementById('rsvpButton').addEventListener('click', function() {
  alert('Сіз RSVP жасадыңыз! Рақмет!');
});